export type AdvantageType = {
  title: string,
  description: string
}

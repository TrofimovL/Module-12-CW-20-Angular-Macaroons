export type MacaroonType = {
  imgSrc: string,
  title: string,
  price: string
}
